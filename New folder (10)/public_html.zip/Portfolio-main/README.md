# Portfolio
### A compilation of materials that display my skills, qualifications, social media, etc.
> This portfolio was developed in HTML & CSS to sharpen my basic front-end skills, please note that you are **not allowed** to reuse this for any purpose.
