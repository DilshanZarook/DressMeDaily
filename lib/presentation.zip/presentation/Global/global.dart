// globals.dart
import 'package:sdgp_test01/presentation/frame_404_bottomsheet/frame_404_bottomsheet.dart';

ItemModel? selectedItem;

void setSelectedItem(ItemModel? item) {
  selectedItem = item;
}