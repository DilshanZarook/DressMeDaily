import 'package:flutter/material.dart';

class AI_selection_page extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('AI Selection'),
      ),
      body: Center(
        child: Text('Content for AI Selection'),
      ),
    );
  }
}
